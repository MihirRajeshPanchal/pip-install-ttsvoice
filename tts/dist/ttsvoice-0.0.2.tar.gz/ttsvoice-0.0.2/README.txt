Simple Text-to-Speech functions 

tts() Function:

->tts(text,voice,tempo)

--->text = Any String

--->voice = ("male","female")

--->tempo = ("high","normal","low")
